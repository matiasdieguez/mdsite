namespace LogSample;

public class FileLogger : ILogger
{
    public void Log(string message)
    {
        var lines = new List<string>
        {
            DateTime.Now.ToString(),
            message
        };

        File.WriteAllLines(@"C:\Source\Curso\LogSample\log.txt", lines);
    }
}