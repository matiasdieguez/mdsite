namespace LogSample;

public interface ILogger
{
    void Log(string message);
}