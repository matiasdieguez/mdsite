﻿using LogSample;

Console.WriteLine("Hello, World!");

var fileLogger = new FileLogger();
fileLogger.Log("hola");

var consoleLogger = new ConsoleLogger();
consoleLogger.Log("chau");

var loggerList = new List<ILogger>();
loggerList.Add(fileLogger);
loggerList.Add(consoleLogger);

loggerList.ForEach(i => i.Log("hola"));

foreach (var i in loggerList)
{
    i.Log("hola");
}

for (var i = 0; i < loggerList.Count; i++)
{
    loggerList[i].Log("hola");
}
