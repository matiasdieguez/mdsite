namespace LogSample;

public class Logger
{
    public void Log()
    {
        Console.WriteLine(DateTime.Now.ToString()+" - Logueado");
    }

    public void Log(string message)
    {
        Console.WriteLine(message);
    }   
}
