using System.Text;
using MarketingOnline.Models;

namespace MarketingOnline.Controllers
{
    public class EmailController
    {
        public static void Send(List<Contact> contacts, List<Product> products)
        {
            var productsText = new StringBuilder();

            foreach (var product in products)
            {
                productsText.AppendLine("Oferta de " + product.Name + " por $" + product.Price);
            }

            //pasara generando la variable contact con los datos
            //de cada item que se encuentre en la lista de contactos
            foreach (var contact in contacts)
            {
                var textMail = productsText.ToString();

                Console.WriteLine("Enviar email a " + contact.Email);
                Console.Write(textMail);
                Console.WriteLine();
            }
        }
    }
}