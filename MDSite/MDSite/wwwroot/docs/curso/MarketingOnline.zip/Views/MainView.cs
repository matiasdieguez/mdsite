using MarketingOnline.Controllers;
using MarketingOnline.Models;

namespace MarketingOnline.Views
{
    public class MainView
    {
        public static void Index()
        {
            //Escribir una linea en la consola
            Console.WriteLine("Bienvenido al sistema de Marketing Online");

            //Crear una instancia de la clase Product
            var product1 = new Product
            {
                Id = 1,
                Name = "Jabon",
                Price = 250
            };
            //Mostrar el producto creado
            Console.WriteLine("Producto " + product1.Name + " disponible para promocionar");

            var product2 = new Product
            {
                Id = 2,
                Name = "Desodorante",
                Price = 1200
            };
            Console.WriteLine("Producto " + product2.Name + " disponible para promocionar");

            var productList = new List<Product>
            { 
                product1,
                product2 
            };


            var contact1 = new Contact
            {
                Id = 1,
                FirstName = "Gonzalo",
                LastName = "Sanchez",
                BirthDate = new DateTime(1995, 1, 2),
                Email = "gonzalo.sanchez608@gmail.com"
            };

            Console.WriteLine("Hola " + contact1.FirstName + " vamos a enviarte emails de promociones");

            var contact2 = new Contact
            {
                Id = 2,
                FirstName = "Damián",
                LastName = "Gravina",
                Email = "damianlionelgravina@gmail.com",
                BirthDate = new DateTime(1995, 2, 5)
            };

            var contactList = new List<Contact>
            {
                contact1,
                contact2
            };

            Console.WriteLine("Hola " + contact2.FirstName + " vamos a enviarte emails de promociones");

            EmailController.Send(contactList, productList);

        }
    }
}