﻿//Agregar el contexto de las clases definidas en el namespace
//para poder utilizarlas


using MarketingOnline.Views;

MainView.Index();

Console.ReadLine();