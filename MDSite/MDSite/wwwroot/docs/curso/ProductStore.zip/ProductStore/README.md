# Product Store System
A system to manage products and orders

## Prerequisites
- .NET 8.0 SDK

    https://dot.net

- RavenDB 

    Docker image

    ```
    docker run -d --name ravendb -p 8080:8080 -p 38888:38888 -v C:/ravendb:/opt/RavenDB/Server/Storage ravendb/ravendb
    ```

    Navigate to http://localhost:8080
    Setup without auth
    No cluster
    Set IP to 0.0.0.0 

## Next steps
- Add HealthChecks
- Add db config in app settings
- Explain custom routes
- Add DTO
- Add API Key
