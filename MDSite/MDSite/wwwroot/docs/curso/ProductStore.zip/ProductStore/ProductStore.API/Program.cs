using Raven.Client.Documents;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Configuration.AddEnvironmentVariables();
builder.Services.AddHealthChecks();

var ravenDBUrl = builder.Configuration["RavenDB:Url"];
var ravenDBDatabase = builder.Configuration["RavenDB:DatabaseName"];

// Configure RavenDB
builder.Services.AddSingleton<IDocumentStore>(provider =>
{
    var store = new DocumentStore
    {
        Urls = [ravenDBUrl], // RavenDB server URL
        Database = ravenDBDatabase // Database name
    };
    store.Initialize();
    return store;
});

builder.Services.AddControllers();


var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseHealthChecks("/health");

app.UseRouting();

app.MapControllers();

app.Run();
