namespace ProductStore.API.Controllers;

using Microsoft.AspNetCore.Mvc;
using ProductStore.API.DTO;
using ProductStore.API.Maps;
using ProductStore.API.Models;
using Raven.Client.Documents;
using System.Threading.Tasks;

[ApiController]
[Route("api/[controller]")]
public class ProductController : ControllerBase
{
    private readonly IDocumentStore _store;

    public ProductController(IDocumentStore store)
    {
        _store = store;
    }

    [HttpGet]
    public async Task<IActionResult> Get()
    {
        using var session = _store.OpenAsyncSession();
        var products = await session.Query<Product>().ToListAsync();
        var list = products.Select(p => p.ToDto()).ToList();
        return Ok(list);
    }

    [HttpGet(nameof(GetExpensives))]
    public async Task<IActionResult> GetExpensives()
    {
        using var session = _store.OpenAsyncSession();
        var product = await session
        .Query<Product>()
        .Where(p => p.Price > 10000)
        .ToListAsync();

        return Ok(product);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(string id)
    {

        using var session = _store.OpenAsyncSession();
        var product = await session.LoadAsync<Product>(id);
        if (product == null)
            return NotFound();
        return Ok(product);
    }

    [HttpPost]
    public async Task<IActionResult> Create(ProductDTO productDTO)
    {
        using var session = _store.OpenAsyncSession();

        var product = productDTO.FromDto();
        product.Id = Guid.NewGuid().ToString();

        await session.StoreAsync(product);
        await session.SaveChangesAsync();
        return CreatedAtAction(nameof(GetById), new { id = product.Id }, productDTO);
    }

    [HttpPut]
    public async Task<IActionResult> Update(Product updatedProduct)
    {
        using var session = _store.OpenAsyncSession();
        var product = await session.LoadAsync<Product>(updatedProduct.Id);
        if (product == null)
            return NotFound();

        product.Name = updatedProduct.Name;
        product.Price = updatedProduct.Price;
        product.Stock = updatedProduct.Stock;

        await session.SaveChangesAsync();
        return NoContent();
    }

    [HttpDelete]
    public async Task<IActionResult> Delete(string id)
    {
        using var session = _store.OpenAsyncSession();
        var product = await session.LoadAsync<Product>(id);
        if (product == null)
            return NotFound();

        session.Delete(product);
        await session.SaveChangesAsync();
        return NoContent();
    }
}
