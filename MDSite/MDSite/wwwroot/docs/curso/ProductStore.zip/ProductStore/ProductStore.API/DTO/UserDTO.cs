namespace ProductStore.API.DTO;

public class UserDTO
{
    public string Name { get; set; }
    public string Email { get; set; }   
}