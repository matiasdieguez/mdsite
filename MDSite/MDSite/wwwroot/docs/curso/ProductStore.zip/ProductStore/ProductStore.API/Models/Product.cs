namespace ProductStore.API.Models;

public class Product
{
    public string Id { get; set; } // RavenDB usa cadenas para los IDs
    public string Name { get; set; }
    public double Price { get; set; }
    public int Stock { get; set; }
}