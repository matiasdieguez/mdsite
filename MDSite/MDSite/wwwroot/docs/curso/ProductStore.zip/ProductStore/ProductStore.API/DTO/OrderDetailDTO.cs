namespace ProductStore.API.DTO;

public class OrderDetailDTO
{
    public string ProductId { get; set; }       
    public double Quantity { get; set;}
}