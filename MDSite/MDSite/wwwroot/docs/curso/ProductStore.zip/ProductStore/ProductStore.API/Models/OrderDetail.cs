namespace ProductStore.API.Models;

public class OrderDetail
{
    public Product Product{ get; set; } 
    public double Quantity { get; set; }
}