namespace ProductStore.API.Models;

public class Order
{
    public string Id { get; set; }
    public User User { get; set; }
    public List<OrderDetail> Details { get; set;}       
}
