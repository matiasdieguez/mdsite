namespace ProductStore.API.DTO;

public class OrderDTO
{
    public string UserId { get; set; }      
    public List<OrderDetailDTO> Details { get; set; }
}
