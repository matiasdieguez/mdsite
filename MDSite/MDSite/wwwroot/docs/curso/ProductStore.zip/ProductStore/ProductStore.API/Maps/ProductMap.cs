using ProductStore.API.DTO;
using ProductStore.API.Models;

namespace ProductStore.API.Maps;

public static class ProductMap
{
    public static Product FromDto(this ProductDTO dto)
    {
        return new Product {
            Price = dto.Price,
            Name = dto.Name,
            Stock = dto.Stock
        };
    }

    public static ProductDTO ToDto(this Product model)
    {
        return new ProductDTO
        {
            Name = model.Name,
            Price = model.Price,
            Stock = model.Stock
        };
    }
}