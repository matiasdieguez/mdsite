﻿/*
Tipos por valor:

int     Entero de 32 bits
long    Entero de 64 bits
double  Decimal
string  Cadena de texto

Tipos por referencia:
object    Objeto del que derivan todos los demas
DateTime  Objeto que representa una fecha y hora
Console   Objeto que representa la consola de comandos
*/


//variables de tipos por valor, implicita usando var
using TestProject;

var text = "Hello, kids!";
Console.WriteLine(text);

var age = 37;
Console.WriteLine(age);

//variable de tipos por valor, explicita usando tipo de dato
int count = 5;
string question = "are you " + count + " ok?";
Console.WriteLine(question);

// Instrucciones. Esta linea es un comentario y no se ejecuta.

/*
Este es un comentario
de multiples lineas
y no se ejecuta
*/

//variable de tipo por referencia (objeto
// la variable ezequiel sera la instancia del objeto del tipo Person
var person1 = new Person();

person1.Id = 1;
person1.FirstName = "Ezequiel";
person1.LastName = "Ferrari";
person1.BirthDate = new DateTime(1997, 10, 8);
Console.WriteLine(person1.FullName);
Console.WriteLine("Age is " + person1.GetAge());
person1.SayHello();

var person2 = new Person();
person2.Id = 2;
person2.FirstName = "Leandro";
person2.LastName = "Cisneros";
person2.BirthDate = new DateTime(1987, 1, 17);
Console.WriteLine(person2.FullName);
Console.WriteLine("Age is " + person2.GetAge());
person2.SayHello();


