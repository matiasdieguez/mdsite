//El namespace corresponde a la estructura de directorio del proyecto
namespace TestProject
{
    //La clase define las propiedades, metodos y eventos de un objeto
    public class Person
    {
        //propiedad que almacena el Id (codigo unico de la persona)
        public int Id { get; set; }

        //propiedad que almacena el nombre
        public string FirstName { get; set; }

        //propiedad que almacena el apellido
        public string LastName { get; set; }

        public string FullName
        {
            get
            {
                return LastName + ", " + FirstName;
            }
        }

        public string Email { get; set; }

        //propiedad que almacena la fecha de nacimiento
        public DateTime BirthDate { get; set; }

        //metodo que realiza una accion
        public void SayHello()
        {
            Console.WriteLine("Hello " + FirstName);
        }

        public double GetAge()
        {
            return (DateTime.Now - BirthDate).TotalDays / 365;
        }

        public void SendMail()
        {
            var text = "Hola " + FirstName + " por favor comprame papas fritas";

            //Cuando desarrollemos la clase EmailSender podremos enviar un email
            //Email.Send(text);
        }
    }
}